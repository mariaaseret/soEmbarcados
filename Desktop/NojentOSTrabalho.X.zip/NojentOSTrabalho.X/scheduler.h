#ifndef SCHEDULER_H
#define	SCHEDULER_H

#include "types.h"

POS_READY_QUEUE priority_scheduler();
POS_READY_QUEUE RR_scheduler();

#endif	/* SCHEDULER_H */
